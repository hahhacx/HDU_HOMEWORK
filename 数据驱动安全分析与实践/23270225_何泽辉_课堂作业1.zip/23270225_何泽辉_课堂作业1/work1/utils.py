import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import torch
import torch.nn as nn


def labels_to_onehot(labels: torch.Tensor, num_classes: int = 2) -> torch.Tensor:
    onehot = torch.zeros(labels.size(0), num_classes, dtype=torch.float32, device=labels.device)
    onehot.scatter_(1, labels.unsqueeze(1).long(), 1.0)
    return onehot


class LossCanvas:
    """用于可视化训练/测试损失"""

    def __init__(self):
        self.train_losses = []
        self.test_losses = []
        self.fig, self.axes = plt.subplots(1, 2, figsize=(12, 8))

    def update(self, train_loss: float, test_loss: float):
        self.train_losses.append(train_loss)
        self.test_losses.append(test_loss)

        self.axes[0].clear()
        self.axes[0].plot(self.train_losses, label="train loss")
        self.axes[0].set_title("Train Loss")
        self.axes[0].set_xlabel("epoch")
        self.axes[0].legend()

        self.axes[1].clear()
        self.axes[1].plot(self.test_losses, label="test loss", color="orange")
        self.axes[1].set_title("Test Loss")
        self.axes[1].set_xlabel("epoch")
        self.axes[1].legend()

        self.fig.tight_layout()


def train_one_epoch(model, train_loader, optimizer, criterion, device) -> float:
    model.train()
    total_loss = 0.0
    for batch_x, batch_y in train_loader:
        batch_x = batch_x.to(device)
        batch_y = batch_y.to(device)
        batch_y_onehot = labels_to_onehot(batch_y)

        optimizer.zero_grad()
        output = model(batch_x)
        loss = criterion(output, batch_y_onehot)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * batch_x.size(0)

    return total_loss / len(train_loader.dataset)


def evaluate(model, x_test, y_test, criterion, device):
    model.eval()
    with torch.no_grad():
        x_test = x_test.to(device)
        y_test = y_test.to(device)
        y_test_onehot = labels_to_onehot(y_test)
        output = model(x_test)
        loss = criterion(output, y_test_onehot).item()
        predicted = torch.argmax(output, dim=1)
        accuracy = (predicted == y_test).float().mean().item()
    return loss, accuracy
