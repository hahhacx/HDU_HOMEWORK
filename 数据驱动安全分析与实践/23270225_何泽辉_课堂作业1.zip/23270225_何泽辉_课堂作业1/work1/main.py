"""
作业1：使用 DNN 完成垃圾邮件分类
数据：spambase.csv（57 个特征，label: 0=非垃圾邮件, 1=垃圾邮件）
"""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False
import numpy as np
import pandas as pd
import seaborn as sns
import torch
import torch.nn as nn
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset

from model import DNNclassification
from utils import LossCanvas, evaluate, train_one_epoch

# 路径配置
BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "data" / "spambase.csv"
FIG_DIR = BASE_DIR / "figures"
FIG_DIR.mkdir(exist_ok=True)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
BATCH_SIZE = 64
EPOCHS = 20
LEARNING_RATE = 0.001
RANDOM_STATE = 42


def load_data():
    """一、数据准备：加载数据"""
    data = pd.read_csv(DATA_PATH)
    print("数据形状:", data.shape)
    print("\n数据前 5 行:")
    print(data.head())
    return data


def explore_data(data: pd.DataFrame):
    """二、数据探索"""
    print("\n=== 数据基本信息 ===")
    data.info()

    print("\n=== 标签分布 ===")
    label_counts = data["label"].value_counts().sort_index()
    print(label_counts)

    fig, ax = plt.subplots(figsize=(6, 4))
    labels = ["非垃圾邮件(0)", "垃圾邮件(1)"]
    counts = [label_counts.get(0, 0), label_counts.get(1, 0)]
    bars = ax.bar(labels, counts, color=["#4C72B0", "#DD8452"])
    ax.set_ylabel("数量")
    ax.set_title("垃圾邮件与非垃圾邮件数量分布")
    ax.set_ylim(0, max(counts) * 1.12)
    for bar, count in zip(bars, counts):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height(),
            str(count),
            ha="center",
            va="bottom",
            fontsize=11,
        )
    fig.tight_layout()
    plt.savefig(FIG_DIR / "label_distribution.png", dpi=120)
    plt.close()

    return label_counts


def split_dataset(data: pd.DataFrame):
    """划分训练集和测试集"""
    x = data.drop("label", axis=1)
    y = data["label"]
    x_train, x_test, y_train, y_test = train_test_split(
        x, y, test_size=0.25, random_state=RANDOM_STATE, stratify=y
    )
    print(f"\n训练集大小: {len(x_train)}, 测试集大小: {len(x_test)}")
    return x_train, x_test, y_train, y_test


def plot_feature_distribution(x: pd.DataFrame, y: pd.Series):
    """使用密度曲线对比不同类别在各特征上的分布"""
    x_np = x.values
    y_np = y.values
    columns_name = x.columns.values

    plt.figure(figsize=(20, 12))
    for i in range(len(columns_name)):
        plt.subplot(7, 9, i + 1)
        sns.kdeplot(x_np[y_np == 0, i], bw_adjust=0.05, color="#4C72B0", fill=True, alpha=0.25, linewidth=1.2, label="非垃圾(0)")
        sns.kdeplot(x_np[y_np == 1, i], bw_adjust=0.05, color="#DD8452", fill=True, alpha=0.25, linewidth=1.2, label="垃圾(1)")
        plt.title(columns_name[i], fontsize=8)
        plt.xticks([])
        plt.yticks([])

    plt.subplots_adjust(hspace=0.8, wspace=0.35)
    plt.savefig(FIG_DIR / "feature_distribution.png", dpi=100, bbox_inches="tight")
    plt.close()


def build_dataloader(x_train, y_train, shuffle: bool = True):
    """将训练数据打包为 DataLoader"""
    x_tensor = torch.tensor(x_train.values, dtype=torch.float32)
    y_tensor = torch.tensor(y_train.values, dtype=torch.long)
    dataset = TensorDataset(x_tensor, y_tensor)
    loader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=shuffle)
    return loader, x_tensor, y_tensor


def run_training(
    model,
    train_loader,
    x_test_tensor,
    y_test_tensor,
    title: str,
    loss_fig_name: str,
):
    """训练并评估模型"""
    criterion = nn.BCELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)
    canvas = LossCanvas()

    print(f"\n=== {title} ===")
    for epoch in range(EPOCHS):
        train_loss = train_one_epoch(model, train_loader, optimizer, criterion, DEVICE)
        test_loss, test_acc = evaluate(model, x_test_tensor, y_test_tensor, criterion, DEVICE)
        canvas.update(train_loss, test_loss)
        print(
            f"Epoch [{epoch + 1}/{EPOCHS}] "
            f"train_loss: {train_loss:.4f}, test_loss: {test_loss:.4f}, test_acc: {test_acc:.4f}"
        )

    canvas.fig.savefig(FIG_DIR / loss_fig_name, dpi=120)
    plt.close(canvas.fig)

    _, final_acc = evaluate(model, x_test_tensor, y_test_tensor, criterion, DEVICE)
    print(f"{title} 最终测试准确率: {final_acc:.4f}")
    return final_acc


def main():
    print(f"使用设备: {DEVICE}")

    # 一、数据准备
    data = load_data()

    # 二、数据探索
    explore_data(data)
    x = data.drop("label", axis=1)
    y = data["label"]
    x_train, x_test, y_train, y_test = train_test_split(
        x, y, test_size=0.25, random_state=RANDOM_STATE, stratify=y
    )
    print(f"\n训练集大小: {len(x_train)}, 测试集大小: {len(x_test)}")
    plot_feature_distribution(x, y)

    # 三、定义全连接网络
    model = DNNclassification().to(DEVICE)
    print("\n=== 网络结构 ===")
    print(model)

    # 四、训练模型
    # 4.1 未标准化数据
    x_test_tensor = torch.tensor(x_test.values, dtype=torch.float32)
    y_test_tensor = torch.tensor(y_test.values, dtype=torch.long)

    train_nots_loader, _, _ = build_dataloader(x_train, y_train)
    print(f"\ntrain_loader 的 batch 数量为: {len(train_nots_loader)}")

    sample_x, sample_y = next(iter(train_nots_loader))
    print("一个 batch 的特征尺寸:", sample_x.shape)
    print("一个 batch 的标签尺寸:", sample_y.shape)

    model_nots = DNNclassification().to(DEVICE)
    acc_raw = run_training(
        model_nots,
        train_nots_loader,
        x_test_tensor,
        y_test_tensor,
        title="未标准化数据训练",
        loss_fig_name="loss_without_standardization.png",
    )

    # 4.2 标准化数据
    scaler = StandardScaler()
    x_train_std = scaler.fit_transform(x_train)
    x_test_std = scaler.transform(x_test)

    x_test_std_tensor = torch.tensor(x_test_std, dtype=torch.float32)
    train_std_loader, _, _ = build_dataloader(
        pd.DataFrame(x_train_std, columns=x_train.columns),
        y_train,
    )

    model_std = DNNclassification().to(DEVICE)
    acc_std = run_training(
        model_std,
        train_std_loader,
        x_test_std_tensor,
        y_test_tensor,
        title="标准化数据训练",
        loss_fig_name="loss_with_standardization.png",
    )

    print("\n=== 训练结果对比 ===")
    print(f"未标准化测试准确率: {acc_raw:.4f}")
    print(f"标准化后测试准确率: {acc_std:.4f}")
    print(f"\n图表已保存至: {FIG_DIR}")


if __name__ == "__main__":
    main()
