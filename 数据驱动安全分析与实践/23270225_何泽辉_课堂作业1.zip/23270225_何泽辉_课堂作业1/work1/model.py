import torch.nn as nn


class DNNclassification(nn.Module):
    """全连接神经网络：57 -> 30 -> 10 -> 2"""

    def __init__(self, input_dim: int = 57, hidden1_dim: int = 30, hidden2_dim: int = 10, output_dim: int = 2):
        super().__init__()
        self.hidden1 = nn.Sequential(
            nn.Linear(input_dim, hidden1_dim),
            nn.ReLU(),
        )
        self.hidden2 = nn.Sequential(
            nn.Linear(hidden1_dim, hidden2_dim),
            nn.ReLU(),
        )
        self.classification = nn.Sequential(
            nn.Linear(hidden2_dim, output_dim),
            nn.Sigmoid(),
        )

    def forward(self, x):
        x = self.hidden1(x)
        x = self.hidden2(x)
        x = self.classification(x)
        return x
