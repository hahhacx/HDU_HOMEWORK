# %% [markdown]
# # PyTorch DNN 实践教程
# 
# 本教程将指导你如何使用PyTorch框架构建一个深度神经网络(DNN)来完成鸢尾花分类任务。通过本教程，你将学习到深度神经网络的基本原理和实现步骤。

# %% [markdown]
# ## 1. 深度神经网络(DNN)基础
# 
# 深度神经网络是一种具有多层结构的神经网络，通常包含： 
# - **输入层**：接收原始数据
# - **隐藏层**：执行数据的非线性变换（可以有多个）
# - **输出层**：产生最终预测结果
# 
# 每一层由多个神经元组成，神经元之间通过权重连接。神经网络通过前向传播计算预测结果，并通过反向传播算法更新权重，以最小化预测误差。
# 
# ### 激活函数
# 
# 激活函数为神经网络引入非线性变换，常用的激活函数包括：
# - **ReLU(修正线性单元)**：f(x) = max(0, x)
# - **Sigmoid**：f(x) = 1/(1+e^(-x))
# - **Tanh**：f(x) = (e^x - e^(-x))/(e^x + e^(-x))
# 
# ### 损失函数
# 
# 损失函数用于衡量模型的预测与真实值之间的差距，常用的损失函数包括：
# - **交叉熵损失**：适用于分类问题
# - **均方误差**：适用于回归问题
# 
# ### 优化器
# 
# 优化器负责更新模型的参数，以最小化损失函数，常用的优化器包括：
# - **随机梯度下降(SGD)**
# - **Adam**：自适应矩估计优化算法
# - **RMSprop**：均方根传播算法

# %% [markdown]
# ## 2. 环境设置
# 
# 首先，导入必要的库：

# %%
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.manifold import TSNE
import logging
from datetime import datetime

# 设置日志记录
def setup_logger(log_file="dnn_tutorial_log.txt"):
    logger = logging.getLogger("DNN_Tutorial")
    logger.setLevel(logging.INFO)
    if logger.hasHandlers():
        logger.handlers.clear()
    fh = logging.FileHandler(log_file, mode='w', encoding='utf-8')
    fh.setLevel(logging.INFO)
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger

logger = setup_logger()
logger.info(f"DNN 教程开始时间: {datetime.now()}")

# 检查是否有可用的GPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"使用设备: {device}")
logger.info(f"使用设备: {device}")

# %% [markdown]
# ## 3. 数据加载与预处理
# 
# 加载鸢尾花数据集并进行预处理：

# %%
# 加载数据集
data = pd.read_csv("../data/iris.csv")
data.head()

# %%
# 查看数据集信息
print(f"数据集形状: {data.shape}")
print(f"类别分布:\n{data['species'].value_counts()}")
logger.info(f"数据集形状: {data.shape}")
logger.info(f"类别分布:\n{data['species'].value_counts()}")

# %% [markdown]
# ### 3.1 数据可视化

# %%
# 可视化特征分布
plt.figure(figsize=(12, 10))
for i, feature in enumerate(['sepal_length', 'sepal_width', 'petal_length', 'petal_width']):
    plt.subplot(2, 2, i+1)
    for species in data['species'].unique():
        plt.hist(data[data['species']==species][feature], 
                 alpha=0.7, label=f'Class {species}', bins=15)
    plt.title(feature)
    plt.legend()
plt.tight_layout()
plt.savefig("dnn_feature_distributions.png", dpi=150, bbox_inches='tight')
print("特征分布图已保存为 dnn_feature_distributions.png")
plt.show()

# %%
# 散点图可视化
plt.figure(figsize=(15, 10))
for i, (x_feature, y_feature) in enumerate([
    ('sepal_length', 'sepal_width'),
    ('petal_length', 'petal_width'),
    ('sepal_length', 'petal_length'),
    ('sepal_width', 'petal_width')
]):
    plt.subplot(2, 2, i+1)
    for species in data['species'].unique():
        plt.scatter(
            data[data['species']==species][x_feature],
            data[data['species']==species][y_feature],
            label=f'Class {species}',
            alpha=0.7
        )
    plt.xlabel(x_feature)
    plt.ylabel(y_feature)
    plt.title(f'{x_feature} vs {y_feature}')
    plt.legend()
plt.tight_layout()
plt.savefig("dnn_scatter_plots.png", dpi=150, bbox_inches='tight')
print("散点图已保存为 dnn_scatter_plots.png")
plt.show()

# %% [markdown]
# ### 3.2 数据预处理

# %%
# 分离特征和标签
X = data.iloc[:, :-1].values
y = data.iloc[:, -1].values

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# 标准化特征
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 转换为PyTorch张量
X_train_tensor = torch.FloatTensor(X_train_scaled)
X_test_tensor = torch.FloatTensor(X_test_scaled)
y_train_tensor = torch.LongTensor(y_train)
y_test_tensor = torch.LongTensor(y_test)

print(f"训练集形状: {X_train_tensor.shape}")
print(f"测试集形状: {X_test_tensor.shape}")
logger.info(f"训练集形状: {X_train_tensor.shape}")
logger.info(f"测试集形状: {X_test_tensor.shape}")

# %% [markdown]
# ## 4. 模型定义
# 
# 定义深度神经网络模型：

# %%
class IrisClassifier(nn.Module):
    def __init__(self, input_size, hidden_size1, hidden_size2, output_size):
        super(IrisClassifier, self).__init__()
        
        # 定义网络结构
        self.fc1 = nn.Linear(input_size, hidden_size1)
        self.fc2 = nn.Linear(hidden_size1, hidden_size2)
        self.fc3 = nn.Linear(hidden_size2, output_size)
        self.dropout = nn.Dropout(0.2)
        
    def forward(self, x):
        # 前向传播
        x = torch.relu(self.fc1(x))
        x = self.dropout(x)
        x = torch.relu(self.fc2(x))
        x = self.dropout(x)
        x = self.fc3(x)
        return x

# 创建模型
input_size = X_train.shape[1]  # 特征数量
hidden_size1 = 32
hidden_size2 = 16
output_size = len(np.unique(y))  # 类别数量

model = IrisClassifier(input_size, hidden_size1, hidden_size2, output_size)
model = model.to(device)
print(model)
logger.info(f"模型结构:\n{model}")

# %% [markdown]
# ## 5. 模型训练
# 
# 定义损失函数和优化器，并训练模型：

# %%
# 定义损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 训练参数
num_epochs = 100
batch_size = 32

# 记录训练损失
losses = []

# 训练循环
for epoch in range(num_epochs):
    # 设置为训练模式
    model.train()
    
    # 随机排列训练数据
    indices = torch.randperm(X_train_tensor.size(0))
    
    # 初始化总损失
    total_loss = 0
    
    # 批次训练
    for start_idx in range(0, X_train_tensor.size(0), batch_size):
        # 提取批次数据
        idx = indices[start_idx:start_idx + batch_size]
        inputs = X_train_tensor[idx].to(device)
        targets = y_train_tensor[idx].to(device)
        
        # 前向传播
        outputs = model(inputs)
        loss = criterion(outputs, targets)
        
        # 反向传播和优化
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        # 累加损失
        total_loss += loss.item() * len(idx)
    
    # 计算平均损失
    avg_loss = total_loss / X_train_tensor.size(0)
    losses.append(avg_loss)
    
    # 每10个epoch打印一次训练信息并记录日志
    if (epoch + 1) % 10 == 0:
        msg = f'Epoch [{epoch+1}/{num_epochs}], Loss: {avg_loss:.4f}'
        print(msg)
        logger.info(msg)

# %%
# 绘制损失曲线并保存
plt.figure(figsize=(10, 6))
plt.plot(range(1, num_epochs+1), losses, marker='o', linestyle='-', markersize=2)
plt.title('Training Loss Over Epochs')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.grid(True)
plt.savefig("dnn_training_loss.png", dpi=150, bbox_inches='tight')
print("训练损失曲线已保存为 dnn_training_loss.png")
plt.show()

# %% [markdown]
# ## 6. 模型评估
# 
# 评估模型在测试集上的性能：

# %%
# 设置为评估模式
model.eval()

# 评估模型
with torch.no_grad():
    # 将测试数据移到设备上
    X_test_device = X_test_tensor.to(device)
    y_test_device = y_test_tensor.to(device)
    
    # 预测
    outputs = model(X_test_device)
    _, predicted = torch.max(outputs, 1)
    
    # 计算准确率
    accuracy = (predicted == y_test_device).sum().item() / y_test_device.size(0)
    print(f'测试准确率: {accuracy:.4f}')
    logger.info(f'测试准确率: {accuracy:.4f}')
    
    # 获取预测结果和真实标签
    y_pred = predicted.cpu().numpy()
    y_true = y_test_device.cpu().numpy()

# %%
# 打印分类报告
class_names = ["Setosa", "Versicolor", "Virginica"]
report = classification_report(y_true, y_pred, target_names=class_names)
print("分类报告:")
print(report)
logger.info(f"分类报告:\n{report}")

# %%
# 绘制混淆矩阵并保存
cm = confusion_matrix(y_true, y_pred)
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
            xticklabels=class_names, yticklabels=class_names)
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix')
plt.savefig("dnn_confusion_matrix.png", dpi=150, bbox_inches='tight')
print("混淆矩阵已保存为 dnn_confusion_matrix.png")
plt.show()

# %% [markdown]
# ## 7. 结果可视化
# 
# 可视化分类结果：

# %%
# 使用t-SNE降维可视化分类结果
tsne = TSNE(n_components=2, random_state=42)
X_test_tsne = tsne.fit_transform(X_test_scaled)

# 创建图形
plt.figure(figsize=(12, 5))

# 绘制真实标签分布
plt.subplot(1, 2, 1)
for i in np.unique(y_true):
    idx = y_true == i
    plt.scatter(X_test_tsne[idx, 0], X_test_tsne[idx, 1], 
                label=class_names[i], alpha=0.7)
plt.title('True Labels')
plt.xlabel('t-SNE feature 1')
plt.ylabel('t-SNE feature 2')
plt.legend()

# 绘制预测标签分布
plt.subplot(1, 2, 2)
for i in np.unique(y_pred):
    idx = y_pred == i
    plt.scatter(X_test_tsne[idx, 0], X_test_tsne[idx, 1], 
                label=class_names[i], alpha=0.7)

# 标记预测错误的点
wrong_idx = y_true != y_pred
if np.any(wrong_idx):
    plt.scatter(X_test_tsne[wrong_idx, 0], X_test_tsne[wrong_idx, 1], 
                s=100, facecolors='none', edgecolors='red', 
                label='Misclassified')

plt.title('Predicted Labels')
plt.xlabel('t-SNE feature 1')
plt.ylabel('t-SNE feature 2')
plt.legend()

plt.tight_layout()
plt.savefig("dnn_tsne_results.png", dpi=150, bbox_inches='tight')
print("t-SNE 可视化结果已保存为 dnn_tsne_results.png")
plt.show()

# %% [markdown]
# ## 8. 保存模型
# 
# 保存训练好的模型：

# %%
# 保存模型到当前文件夹
torch.save(model.state_dict(), "dnn_iris_model.pth")
print("模型已保存到 dnn_iris_model.pth")
logger.info("模型已保存到 dnn_iris_model.pth")

# %% [markdown]
# ## 9. 模型应用
# 
# 使用模型进行预测：

# %%
# 创建示例数据
sample_data = [
    [5.1, 3.5, 1.4, 0.2],  # 预期是Setosa
    [6.2, 2.9, 4.3, 1.3],  # 预期是Versicolor
    [6.5, 3.0, 5.2, 2.0]   # 预期是Virginica
]

# 预处理数据
sample_data_scaled = scaler.transform(sample_data)
sample_tensor = torch.FloatTensor(sample_data_scaled).to(device)

# 预测
model.eval()
with torch.no_grad():
    outputs = model(sample_tensor)
    probabilities = torch.softmax(outputs, dim=1)
    _, predicted = torch.max(outputs, 1)

# 打印结果
print("预测结果:")
for i, (sample, pred, prob) in enumerate(zip(sample_data, predicted, probabilities)):
    print(f"样本 {i+1}: {sample}")
    print(f"预测类别: {class_names[pred]}")
    print(f"预测概率: {prob.cpu().numpy()}")
    print("--------------------")

logger.info("模型应用示例完成")

# %% [markdown]
# ## 10. 总结
# 
# 在本教程中，我们学习了如何使用PyTorch框架构建和训练一个深度神经网络模型来解决鸢尾花分类问题。我们经历了以下步骤：
# 
# 1. 数据加载和预处理
# 2. 数据可视化和分析
# 3. 构建神经网络模型
# 4. 训练模型并监控损失
# 5. 评估模型性能
# 6. 可视化分类结果
# 7. 保存和应用模型
# 
# 通过完成本教程中的实践任务，你已经掌握了使用PyTorch构建深度神经网络的基础知识。鼓励你尝试调整网络结构、超参数或使用不同的数据集来进一步提高你的技能。

# %%
logger.info(f"DNN 教程结束时间: {datetime.now()}")