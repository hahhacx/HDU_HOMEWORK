# PyTorch DNN 实践项目

## 项目简介
本项目旨在帮助学生掌握使用PyTorch框架构建和训练深度神经网络(DNN)的基础知识。通过完成本项目中的任务，学生将学习到数据加载、模型搭建、训练过程以及模型评估的基本流程。

## 学习目标
1. 理解深度神经网络的基本结构和原理
2. 掌握PyTorch框架的基本使用方法
3. 学习如何处理和加载数据集
4. 实现一个简单的深度神经网络模型
5. 训练模型并评估其性能

## 环境要求
- Python 3.6+
- PyTorch 1.7+
- NumPy
- Matplotlib
- scikit-learn

## 项目结构
```
pytorch_dnn_practice/
│
├── README.md               # 项目说明文档
├── requirements.txt        # 项目依赖
├── data/                   # 数据集目录
│   └── iris.csv            # 鸢尾花数据集
│
├── src/                    # 源代码目录
│   ├── data_loader.py      # 数据加载和预处理模块
│   ├── model.py            # 模型定义模块
│   ├── train.py            # 模型训练模块
│   └── evaluate.py         # 模型评估模块
│
└── notebooks/              # Jupyter笔记本目录
    └── dnn_tutorial.ipynb  # 教程笔记本
```

## 任务列表

### 任务1：数据处理
完成 `data_loader.py` 中的数据加载和预处理函数，要求：
- 加载鸢尾花数据集
- 将数据集分为训练集和测试集
- 对数据进行标准化处理
- 将数据转换为PyTorch的张量格式

### 任务2：模型构建
在 `model.py` 中完成DNN模型的定义，要求：
- 创建一个包含至少两个隐藏层的全连接神经网络
- 输入层节点数应与特征数量匹配
- 输出层节点数应与类别数量匹配
- 使用合适的激活函数

### 任务3：模型训练
完成 `train.py` 中的模型训练函数，要求：
- 使用SGD或Adam优化器
- 使用交叉熵损失函数
- 实现训练循环（多个epoch）
- 记录并打印训练过程中的损失值

### 任务4：模型评估
完成 `evaluate.py` 中的模型评估函数，要求：
- 计算模型在测试集上的准确率
- 可视化模型预测结果
- 生成混淆矩阵

## 提交要求
1. 完成所有任务中的代码部分
2. 提交一份简短的报告，描述你的实现过程和结果分析
3. 可以尝试调整网络结构和参数，观察性能变化

## 参考资源
- [PyTorch官方文档](https://pytorch.org/docs/stable/index.html)
- [Deep Learning with PyTorch](https://pytorch.org/tutorials/)
- [鸢尾花数据集介绍](https://scikit-learn.org/stable/auto_examples/datasets/plot_iris_dataset.html)

## 注意事项
- 本练习主要针对DNN的基础知识，难度适中
- 提供的代码框架中已包含部分注释和提示
- 如遇到问题，可参考提供的教程笔记本

祝你学习愉快！ 