import torch
import torch.nn as nn
import torch.nn.functional as F

import torch
import torch.nn as nn

class IrisClassifier(nn.Module):
    def __init__(self, input_size, hidden_size1, hidden_size2, output_size):
        super(IrisClassifier, self).__init__()   
        
        self.fc1 = nn.Linear(input_size, hidden_size1)
        self.fc2 = nn.Linear(hidden_size1, hidden_size2)
        self.fc3 = nn.Linear(hidden_size2, output_size)
        self.dropout = nn.Dropout(0.2)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.dropout(x)
        x = torch.relu(self.fc2(x))
        x = self.dropout(x)
        x = self.fc3(x)
        return x


class IrisClassifierThreeHidden(nn.Module):
    """三个隐藏层的鸢尾花分类器"""
    def __init__(self, input_size, hidden_size1, hidden_size2, hidden_size3, output_size, dropout_rate=0.2):
        super(IrisClassifierThreeHidden, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size1)
        self.fc2 = nn.Linear(hidden_size1, hidden_size2)
        self.fc3 = nn.Linear(hidden_size2, hidden_size3)
        self.fc4 = nn.Linear(hidden_size3, output_size)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.dropout(x)
        x = torch.relu(self.fc2(x))
        x = self.dropout(x)
        x = torch.relu(self.fc3(x))
        x = self.dropout(x)
        x = self.fc4(x)
        return x


class IrisClassifierOneHidden(nn.Module):
    """一个隐藏层的鸢尾花分类器"""
    def __init__(self, input_size, hidden_size, output_size, dropout_rate=0.2):
        super(IrisClassifierOneHidden, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, output_size)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.fc2(x)
        return x



def create_model(input_size, output_size, num_hidden_layers=2):
    if num_hidden_layers == 1:
        hidden_size = 64
        model = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(hidden_size, output_size)
        )
    elif num_hidden_layers == 3:
        h1, h2, h3 = 32, 16, 8
        model = nn.Sequential(
            nn.Linear(input_size, h1), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(h1, h2), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(h2, h3), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(h3, output_size)
        )
    else:  # 默认两个隐藏层
        h1, h2 = 32, 16
        model = nn.Sequential(
            nn.Linear(input_size, h1), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(h1, h2), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(h2, output_size)
        )
    return model

if __name__ == "__main__":
    # 测试模型
    input_size = 4  # 鸢尾花数据集有4个特征
    output_size = 3  # 鸢尾花数据集有3个类别
    
    # 创建模型
    model = create_model(input_size, output_size)
    print(model)
    
    # 测试前向传播
    sample_input = torch.randn(10, input_size)  # 创建10个随机样本
    output = model(sample_input)
    
    print(f"输入形状: {sample_input.shape}")
    print(f"输出形状: {output.shape}")
    print(f"输出示例:\n{output[:2]}")  # 打印前两个样本的输出