import torch
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, classification_report
import seaborn as sns
import os
import sys
import logging
from datetime import datetime

# 修改导入
from data_loader import load_iris_data
from model import create_model

def setup_logger(log_file="evaluation_log.txt"):
    """配置日志记录器"""
    logger = logging.getLogger("EvalLogger")
    logger.setLevel(logging.INFO)
    if logger.hasHandlers():
        logger.handlers.clear()
    fh = logging.FileHandler(log_file, mode='w', encoding='utf-8')
    fh.setLevel(logging.INFO)
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger

def evaluate_model(model, test_loader, criterion, device="cpu"):
    """
    评估模型性能
    """
    model = model.to(device)
    model.eval()

    test_loss = 0.0
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs = inputs.to(device)
            labels = labels.to(device)

            outputs = model(inputs)
            loss = criterion(outputs, labels)
            test_loss += loss.item() * inputs.size(0)

            _, preds = torch.max(outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    test_loss = test_loss / len(test_loader.dataset)
    all_preds = np.array(all_preds)
    all_labels = np.array(all_labels)
    accuracy = (all_preds == all_labels).sum() / len(all_labels)

    return test_loss, accuracy, all_preds, all_labels

def plot_confusion_matrix(y_true, y_pred, class_names=None, save_path="confusion_matrix.png"):
    """绘制混淆矩阵并保存"""
    cm = confusion_matrix(y_true, y_pred)
    if class_names is None:
        class_names = [f"Class {i}" for i in range(cm.shape[0])]

    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=class_names, yticklabels=class_names)
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title('Confusion Matrix')
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"混淆矩阵已保存到 {save_path}")
    plt.show()

def visualize_results(X, y_true, y_pred, feature_idx=(0, 1), save_path="classification_results.png"):
    """可视化分类结果（使用前两个特征）并保存"""
    if isinstance(X, torch.Tensor):
        X = X.cpu().numpy()

    plt.figure(figsize=(12, 5))

    # 真实标签
    plt.subplot(1, 2, 1)
    for i in np.unique(y_true):
        idx = y_true == i
        plt.scatter(X[idx, feature_idx[0]], X[idx, feature_idx[1]],
                    label=f'Class {i}', alpha=0.7)
    plt.title('True Labels')
    plt.xlabel(f'Feature {feature_idx[0]}')
    plt.ylabel(f'Feature {feature_idx[1]}')
    plt.legend()

    # 预测标签
    plt.subplot(1, 2, 2)
    for i in np.unique(y_pred):
        idx = y_pred == i
        plt.scatter(X[idx, feature_idx[0]], X[idx, feature_idx[1]],
                    label=f'Class {i}', alpha=0.7)
    wrong_idx = y_true != y_pred
    if np.any(wrong_idx):
        plt.scatter(X[wrong_idx, feature_idx[0]], X[wrong_idx, feature_idx[1]],
                    s=100, facecolors='none', edgecolors='red', label='Misclassified')
    plt.title('Predicted Labels')
    plt.xlabel(f'Feature {feature_idx[0]}')
    plt.ylabel(f'Feature {feature_idx[1]}')
    plt.legend()

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"分类结果可视化已保存到 {save_path}")
    plt.show()

if __name__ == "__main__":
    torch.manual_seed(42)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"使用设备: {device}")

    # 设置日志
    logger = setup_logger("evaluation_log.txt")
    logger.info(f"评估开始时间: {datetime.now()}")
    logger.info(f"使用设备: {device}")

    data_path = "../data/iris.csv"
    train_loader, test_loader, input_size, output_size = load_iris_data(data_path)

    model = create_model(input_size, output_size)
    model_path = "iris_model.pth"   # 修改为当前文件夹下的模型文件
    if os.path.exists(model_path):
        model.load_state_dict(torch.load(model_path, map_location=device))
        logger.info(f"模型已从 {model_path} 加载")
    else:
        logger.error(f"找不到已训练的模型 {model_path}，请先运行 train.py 训练模型")
        sys.exit(1)

    criterion = torch.nn.CrossEntropyLoss()
    test_loss, accuracy, all_preds, all_labels = evaluate_model(
        model, test_loader, criterion, device
    )

    logger.info(f"测试损失: {test_loss:.4f}")
    logger.info(f"测试准确率: {accuracy:.4f}")

    class_names = ["Setosa", "Versicolor", "Virginica"]
    report = classification_report(all_labels, all_preds, target_names=class_names)
    print("\n分类报告:")
    print(report)
    logger.info(f"分类报告:\n{report}")

    # 保存混淆矩阵到当前文件夹
    plot_confusion_matrix(all_labels, all_preds, class_names,
                          save_path="confusion_matrix.png")

    # 取一个批次的数据用于可视化
    for inputs, labels in test_loader:
        X_sample = inputs.cpu().numpy()
        y_true_sample = labels.cpu().numpy()
        with torch.no_grad():
            outputs = model(inputs.to(device))
            _, y_pred_sample = torch.max(outputs, 1)
            y_pred_sample = y_pred_sample.cpu().numpy()
        break

    visualize_results(X_sample, y_true_sample, y_pred_sample,
                      feature_idx=(0, 1), save_path="classification_results.png")
    
    logger.info(f"评估结束时间: {datetime.now()}")