import pandas as pd
import numpy as np
import torch
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from torch.utils.data import DataLoader, TensorDataset
import os

def load_iris_data(file_path, test_size=0.2, random_state=42, batch_size=32):
    """
    加载鸢尾花数据集并进行预处理

    参数:
        file_path (str): 数据集文件路径
        test_size (float): 测试集比例
        random_state (int): 随机种子
        batch_size (int): 批次大小

    返回:
        train_loader (DataLoader): 训练数据加载器
        test_loader (DataLoader): 测试数据加载器
        input_size (int): 输入特征的维度
        output_size (int): 输出类别的数量
    """
    # 检查数据文件是否存在，若不存在则从sklearn生成并保存
    if not os.path.exists(file_path):
        from sklearn.datasets import load_iris
        iris = load_iris()
        df = pd.DataFrame(iris.data, columns=iris.feature_names)
        df['species'] = iris.target
        # 将target转为类别名（可选）
        # df['species'] = df['species'].map({0:'setosa',1:'versicolor',2:'virginica'})
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        df.to_csv(file_path, index=False)
        print(f"数据文件不存在，已自动生成并保存至 {file_path}")

    # 步骤1: 使用pandas加载CSV文件
    data = pd.read_csv(file_path)

    # 步骤2: 分离特征和标签
    X = data.iloc[:, :-1].values  # 特征
    y_raw = data.iloc[:, -1].values  # 原始标签（可能是字符串或整数）

    # 将标签转换为整数编码
    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(y_raw)

    # 步骤3: 划分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    # 步骤4: 对特征进行标准化处理
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # 步骤5: 转换为PyTorch张量
    X_train_tensor = torch.FloatTensor(X_train_scaled)
    X_test_tensor = torch.FloatTensor(X_test_scaled)
    y_train_tensor = torch.LongTensor(y_train)
    y_test_tensor = torch.LongTensor(y_test)

    # 步骤6: 创建PyTorch数据集和数据加载器
    train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
    test_dataset = TensorDataset(X_test_tensor, y_test_tensor)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    input_size = X_train.shape[1]          # 特征数量
    output_size = len(np.unique(y))        # 类别数量

    return train_loader, test_loader, input_size, output_size

if __name__ == "__main__":
    # 测试数据加载功能
    train_loader, test_loader, input_size, output_size = load_iris_data("../data/iris.csv")
    print(f"数据加载成功！")
    print(f"输入特征维度: {input_size}")
    print(f"输出类别数量: {output_size}")
    print(f"训练样本数量: {len(train_loader.dataset)}")
    print(f"测试样本数量: {len(test_loader.dataset)}")

    # 打印一个批次的数据形状
    for batch_X, batch_y in train_loader:
        print(f"批次特征形状: {batch_X.shape}")
        print(f"批次标签形状: {batch_y.shape}")
        break