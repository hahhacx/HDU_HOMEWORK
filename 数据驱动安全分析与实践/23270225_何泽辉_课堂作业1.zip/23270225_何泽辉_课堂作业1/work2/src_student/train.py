import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
import os
import sys
import logging
from datetime import datetime

# 修改导入方式，因为所有文件在同一目录下
from data_loader import load_iris_data
from model import create_model

def setup_logger(log_file="training_log.txt"):
    """配置日志记录器，同时输出到控制台和文件"""
    logger = logging.getLogger("TrainLogger")
    logger.setLevel(logging.INFO)
    
    # 清除已有的处理器，避免重复
    if logger.hasHandlers():
        logger.handlers.clear()
    
    # 文件处理器（每次覆盖）
    fh = logging.FileHandler(log_file, mode='w', encoding='utf-8')
    fh.setLevel(logging.INFO)
    
    # 控制台处理器
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    
    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger

def train_model(model, train_loader, criterion, optimizer, num_epochs=100, device="cpu", logger=None):
    """
    训练神经网络模型
    """
    model = model.to(device)
    losses = []

    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0

        for inputs, labels in train_loader:
            inputs = inputs.to(device)
            labels = labels.to(device)

            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item() * inputs.size(0)

        epoch_loss = running_loss / len(train_loader.dataset)
        losses.append(epoch_loss)

        if (epoch + 1) % 10 == 0:
            msg = f'Epoch [{epoch+1}/{num_epochs}], Loss: {epoch_loss:.4f}'
            print(msg)
            if logger:
                logger.info(msg)
        else:
            # 每个 epoch 都记录到日志（可选，这里只记录每 10 个 epoch）
            if logger and (epoch + 1) % 10 == 0:
                pass  # 已经记录

    return model, losses

def plot_loss(losses, save_path="training_loss.png"):
    """绘制损失曲线并保存"""
    plt.figure(figsize=(10, 6))
    plt.plot(range(1, len(losses)+1), losses, marker='o', linestyle='-', markersize=2)
    plt.title('Training Loss Over Epochs')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.grid(True)
    # 保存图像
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"损失曲线已保存到 {save_path}")
    plt.show()

if __name__ == "__main__":
    torch.manual_seed(42)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"使用设备: {device}")

    # 设置日志
    logger = setup_logger("training_log.txt")
    logger.info(f"训练开始时间: {datetime.now()}")
    logger.info(f"使用设备: {device}")

    # 数据路径（相对于当前脚本的位置）
    data_path = "../data/iris.csv"
    train_loader, test_loader, input_size, output_size = load_iris_data(data_path)

    model = create_model(input_size, output_size)
    logger.info(f"模型结构:\n{model}")

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    num_epochs = 100
    trained_model, losses = train_model(model, train_loader, criterion, optimizer, num_epochs, device, logger)

    # 保存损失曲线（保存到当前文件夹）
    plot_loss(losses, save_path="training_loss.png")
    
    # 保存模型（保存到当前文件夹）
    torch.save(trained_model.state_dict(), "iris_model.pth")
    logger.info("模型训练完成并已保存到 iris_model.pth")
    logger.info(f"训练结束时间: {datetime.now()}")