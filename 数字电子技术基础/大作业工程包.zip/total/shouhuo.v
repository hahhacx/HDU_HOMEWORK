module shouhuo(A,B,one,two,three,four,R,P);
	input [3:0] A;
	input one;
	input two;
	input three;
	input four;
	input P;
	output [3:0] B;
	output R;
	reg [3:0] B;
	reg R;
	always @(A,B,one,two,three,four,R,P)begin
	if(P==1)begin
		if(one==1&&two==0&&three==0&&four==0)begin		//只买一号商品，3元
			case(A)
				4'b0000: begin B<=4'b0000;R<=1'b0; end
				4'b0001: begin B<=4'b0001;R<=1'b0; end
				4'b0010: begin B<=4'b0010;R<=1'b0; end
				4'b0011: begin B<=4'b0000;R<=1'b1; end
				4'b0100: begin B<=4'b0001;R<=1'b1; end
				4'b0101: begin B<=4'b0010;R<=1'b1; end
				4'b0110: begin B<=4'b0011;R<=1'b1; end
				4'b0111: begin B<=4'b0100;R<=1'b1; end
				4'b1000: begin B<=4'b0101;R<=1'b1; end
				4'b1001: begin B<=4'b0110;R<=1'b1; end
				default: begin B<=4'b0000;R<=1'b0; end
			endcase
		end
		if(one==0&&two==1&&three==0&&four==0)begin		//只买二号商品，4元
			case(A)
				4'b0000: begin B<=4'b0000;R<=1'b0; end
				4'b0001: begin B<=4'b0001;R<=1'b0; end
				4'b0010: begin B<=4'b0010;R<=1'b0; end
				4'b0011: begin B<=4'b0011;R<=1'b0; end
				4'b0100: begin B<=4'b0000;R<=1'b1; end
				4'b0101: begin B<=4'b0001;R<=1'b1; end
				4'b0110: begin B<=4'b0010;R<=1'b1; end
				4'b0111: begin B<=4'b0011;R<=1'b1; end
				4'b1000: begin B<=4'b0100;R<=1'b1; end
				4'b1001: begin B<=4'b0101;R<=1'b1; end
				default: begin B<=4'b0000;R<=1'b0; end
			endcase
		end
		if(one==0&&two==0&&three==1&&four==0)begin		//只买三号商品，5元
			case(A)
				4'b0000: begin B<=4'b0000;R<=1'b0; end
				4'b0001: begin B<=4'b0001;R<=1'b0; end
				4'b0010: begin B<=4'b0010;R<=1'b0; end
				4'b0011: begin B<=4'b0011;R<=1'b0; end
				4'b0100: begin B<=4'b0100;R<=1'b0; end
				4'b0101: begin B<=4'b0000;R<=1'b1; end
				4'b0110: begin B<=4'b0001;R<=1'b1; end
				4'b0111: begin B<=4'b0010;R<=1'b1; end
				4'b1000: begin B<=4'b0011;R<=1'b1; end
				4'b1001: begin B<=4'b0100;R<=1'b1; end
				default: begin B<=4'b0000;R<=1'b0; end
			endcase
		end
		if(one==0&&two==0&&three==0&&four==1)begin		//只买四号商品，3元
			case(A)
				4'b0000: begin B<=4'b0000;R<=1'b0; end
				4'b0001: begin B<=4'b0001;R<=1'b0; end
				4'b0010: begin B<=4'b0010;R<=1'b0; end
				4'b0011: begin B<=4'b0000;R<=1'b1; end
				4'b0100: begin B<=4'b0001;R<=1'b1; end
				4'b0101: begin B<=4'b0010;R<=1'b1; end
				4'b0110: begin B<=4'b0011;R<=1'b1; end
				4'b0111: begin B<=4'b0100;R<=1'b1; end
				4'b1000: begin B<=4'b0101;R<=1'b1; end
				4'b1001: begin B<=4'b0110;R<=1'b1; end
				default: begin B<=4'b0000;R<=1'b0; end
			endcase
		end
		if(one==1&&two==1&&three==0&&four==0)begin		//一号和二号商品，7元
			case(A)
				4'b0000: begin B<=4'b0000;R<=1'b0; end
				4'b0001: begin B<=4'b0001;R<=1'b0; end
				4'b0010: begin B<=4'b0010;R<=1'b0; end
				4'b0011: begin B<=4'b0011;R<=1'b0; end
				4'b0100: begin B<=4'b0100;R<=1'b0; end
				4'b0101: begin B<=4'b0101;R<=1'b0; end
				4'b0110: begin B<=4'b0110;R<=1'b0; end
				4'b0111: begin B<=4'b0000;R<=1'b1; end
				4'b1000: begin B<=4'b0001;R<=1'b1; end
				4'b1001: begin B<=4'b0010;R<=1'b1; end
				default: begin B<=4'b0000;R<=1'b0; end
			endcase
		end
		if(one==1&&two==0&&three==1&&four==0)begin		//一号和三号商品，8元
			case(A)
				4'b0000: begin B<=4'b0000;R<=1'b0; end
				4'b0001: begin B<=4'b0001;R<=1'b0; end
				4'b0010: begin B<=4'b0010;R<=1'b0; end
				4'b0011: begin B<=4'b0011;R<=1'b0; end
				4'b0100: begin B<=4'b0100;R<=1'b0; end
				4'b0101: begin B<=4'b0101;R<=1'b0; end
				4'b0110: begin B<=4'b0110;R<=1'b0; end
				4'b0111: begin B<=4'b0111;R<=1'b0; end
				4'b1000: begin B<=4'b0000;R<=1'b1; end
				4'b1001: begin B<=4'b0001;R<=1'b1; end
				default: begin B<=4'b0000;R<=1'b0; end
			endcase
		end
		if(one==1&&two==0&&three==0&&four==1)begin		//一号和四号商品，6元
			case(A)
				4'b0000: begin B<=4'b0000;R<=1'b0; end
				4'b0001: begin B<=4'b0001;R<=1'b0; end
				4'b0010: begin B<=4'b0010;R<=1'b0; end
				4'b0011: begin B<=4'b0011;R<=1'b0; end
				4'b0100: begin B<=4'b0100;R<=1'b0; end
				4'b0101: begin B<=4'b0101;R<=1'b0; end
				4'b0110: begin B<=4'b0000;R<=1'b1; end
				4'b0111: begin B<=4'b0001;R<=1'b1; end
				4'b1000: begin B<=4'b0010;R<=1'b1; end
				4'b1001: begin B<=4'b0011;R<=1'b1; end
				default: begin B<=4'b0000;R<=1'b0; end
			endcase
		end
		if(one==0&&two==1&&three==1&&four==0)begin		//二号和三号商品，9元
			case(A)
				4'b0000: begin B<=4'b0000;R<=1'b0; end
				4'b0001: begin B<=4'b0001;R<=1'b0; end
				4'b0010: begin B<=4'b0010;R<=1'b0; end
				4'b0011: begin B<=4'b0011;R<=1'b0; end
				4'b0100: begin B<=4'b0100;R<=1'b0; end
				4'b0101: begin B<=4'b0101;R<=1'b0; end
				4'b0110: begin B<=4'b0110;R<=1'b0; end
				4'b0111: begin B<=4'b0111;R<=1'b0; end
				4'b1000: begin B<=4'b1000;R<=1'b0; end
				4'b1001: begin B<=4'b0000;R<=1'b1; end
				default: begin B<=4'b0000;R<=1'b0; end
			endcase
		end
		if(one==0&&two==1&&three==0&&four==1)begin		//二号和四号商品，7元
			case(A)
				4'b0000: begin B<=4'b0000;R<=1'b0; end
				4'b0001: begin B<=4'b0001;R<=1'b0; end
				4'b0010: begin B<=4'b0010;R<=1'b0; end
				4'b0011: begin B<=4'b0011;R<=1'b0; end
				4'b0100: begin B<=4'b0100;R<=1'b0; end
				4'b0101: begin B<=4'b0101;R<=1'b0; end
				4'b0110: begin B<=4'b0110;R<=1'b0; end
				4'b0111: begin B<=4'b0000;R<=1'b1; end
				4'b1000: begin B<=4'b0001;R<=1'b1; end
				4'b1001: begin B<=4'b0010;R<=1'b1; end
				default: begin B<=4'b0000;R<=1'b0; end
			endcase
		end
		if(one==0&&two==0&&three==1&&four==1)begin		//三号和四号商品，8元
			case(A)
				4'b0000: begin B<=4'b0000;R<=1'b0; end
				4'b0001: begin B<=4'b0001;R<=1'b0; end
				4'b0010: begin B<=4'b0010;R<=1'b0; end
				4'b0011: begin B<=4'b0011;R<=1'b0; end
				4'b0100: begin B<=4'b0100;R<=1'b0; end
				4'b0101: begin B<=4'b0101;R<=1'b0; end
				4'b0110: begin B<=4'b0110;R<=1'b0; end
				4'b0111: begin B<=4'b0111;R<=1'b0; end
				4'b1000: begin B<=4'b0000;R<=1'b1; end
				4'b1001: begin B<=4'b0001;R<=1'b1; end
				default: begin B<=4'b0000;R<=1'b0; end
			endcase
		end
	end
	else begin
		if(one==0&&two==0&&three==0&&four==0)begin			//初始状态
			case(A)
				4'b0000: begin B<=4'b0000;R<=1'b1; end
				4'b0001: begin B<=4'b0001;R<=1'b1; end
				4'b0010: begin B<=4'b0010;R<=1'b1; end
				4'b0011: begin B<=4'b0011;R<=1'b1; end
				4'b0100: begin B<=4'b0100;R<=1'b1; end
				4'b0101: begin B<=4'b0101;R<=1'b1; end
				4'b0110: begin B<=4'b0110;R<=1'b1; end
				4'b0111: begin B<=4'b0111;R<=1'b1; end
				4'b1000: begin B<=4'b1000;R<=1'b1; end
				4'b1001: begin B<=4'b1001;R<=1'b1; end
				default: begin B<=4'b0000;R<=1'b0; end
			endcase
		end
	end
	end
endmodule
		