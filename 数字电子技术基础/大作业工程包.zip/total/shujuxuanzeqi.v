module shujuxuanzeqi(Q,data_out);
    input [2:0] Q;
    output [3:0] data_out;
    reg [3:0] data_out;

    always @(Q)
        case(Q)
            3'b000: data_out <= 4'b0001;
            3'b001: data_out <= 4'b0011;
            3'b010: data_out <= 4'b0010;
            3'b011: data_out <= 4'b0100;
            3'b100: data_out <= 4'b0011;
            3'b101: data_out <= 4'b0101;
            3'b110: data_out <= 4'b0100;
            3'b111: data_out <= 4'b0011;
            default: data_out <= 4'b0000;
        endcase
endmodule

